# hw5_Basic-Algorithms-in-Artificial-Intelligence
`task1`-`task5`依次实现了PCA降维、ISOMAP降维、LLE降维、t-SNE降维和UMAP降维
